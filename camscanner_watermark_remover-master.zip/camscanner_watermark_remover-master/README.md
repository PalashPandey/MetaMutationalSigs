# camscanner_watermark_remover
This Flask App would remove CamScanner watermark from scanned pdfs.

Post Link : https://viveksb007.wordpress.com/2018/04/07/uploading-processing-and-downloading-files-in-flask/

Demo Link : https://www.youtube.com/watch?v=tANTbMUk7jc
